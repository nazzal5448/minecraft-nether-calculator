/**
 * Overworld ↔ Nether horizontal coordinates (vanilla 1:8 scale). Y is not scaled.
 * Mirrors web/src/scripts/nether-calculator.ts
 */
(function () {
  var status = document.getElementById("nc-status");

  function announce(msg) {
    if (!status) return;
    status.textContent = "";
    window.setTimeout(function () {
      status.textContent = msg;
    }, 10);
  }

  function parseNum(v) {
    var t = String(v).trim();
    if (t === "" || t === "-" || t === "+") return null;
    var n = Number(t);
    return Number.isFinite(n) ? n : null;
  }

  function floorDiv8(n) {
    return Math.floor(n / 8);
  }

  function direction() {
    var c = document.querySelector('input[name="nc-direction"]:checked');
    return c && c.value === "nether" ? "nether" : "ow";
  }

  var form = document.getElementById("nc-form");
  var xIn = document.getElementById("nc-x");
  var zIn = document.getElementById("nc-z");
  var yIn = document.getElementById("nc-y");
  var outOw = document.getElementById("nc-out-ow");
  var outN = document.getElementById("nc-out-nether");
  var hint = document.getElementById("nc-hint");

  function update() {
    var x = xIn ? parseNum(xIn.value) : null;
    var z = zIn ? parseNum(zIn.value) : null;
    var y = yIn ? parseNum(yIn.value) : null;
    var yStr = y != null ? String(Math.trunc(y)) : "—";

    if (x == null || z == null) {
      if (outOw) outOw.textContent = "—";
      if (outN) outN.textContent = "—";
      if (hint) hint.hidden = true;
      return;
    }

    var xi = Math.trunc(x);
    var zi = Math.trunc(z);

    if (direction() === "ow") {
      var nx = floorDiv8(xi);
      var nz = floorDiv8(zi);
      if (outOw) outOw.textContent = xi + "  " + yStr + "  " + zi;
      if (outN) outN.textContent = nx + "  " + yStr + "  " + nz;
      if (hint) {
        hint.hidden = false;
        hint.textContent = "Overworld → Nether: X and Z ÷8 (floor). Y unchanged.";
      }
    } else {
      var ox = xi * 8;
      var oz = zi * 8;
      if (outOw) outOw.textContent = ox + "  " + yStr + "  " + oz;
      if (outN) outN.textContent = xi + "  " + yStr + "  " + zi;
      if (hint) {
        hint.hidden = false;
        hint.textContent = "Nether → Overworld: X and Z ×8. Y unchanged.";
      }
    }
  }

  if (form) {
    form.addEventListener("input", update);
    form.addEventListener("change", update);
  }
  document.querySelectorAll('input[name="nc-direction"]').forEach(function (el) {
    el.addEventListener("change", update);
  });
  update();

  document.getElementById("nc-copy-ow")?.addEventListener("click", function () {
    var t = outOw && outOw.textContent ? outOw.textContent.trim() : "";
    if (t && t !== "—") {
      navigator.clipboard.writeText(t.replace(/\s+/g, " "));
      announce("Copied overworld coordinates.");
    }
  });
  document.getElementById("nc-copy-nether")?.addEventListener("click", function () {
    var t = outN && outN.textContent ? outN.textContent.trim() : "";
    if (t && t !== "—") {
      navigator.clipboard.writeText(t.replace(/\s+/g, " "));
      announce("Copied nether coordinates.");
    }
  });
})();
