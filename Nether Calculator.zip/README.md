# Nether Calculator - Chrome extension

Same math as [orefinder.io/nether-calculator](https://orefinder.io/nether-calculator): **overworld X/Z ÷8 (floor)** to nether, **nether X/Z ×8** to overworld; **Y passes through** (not scaled). No network access.

## Load in Chrome

1. Open `chrome://extensions`
2. Enable **Developer mode**
3. **Load unpacked** → select this folder (`nether-calculator-chrome`)

## Accessibility and readability updates

- Higher color contrast for text and controls.
- Visible `:focus-visible` ring for keyboard users.
- Explicit field labels and improved result region semantics.
- Screen reader status announcement after copy actions.

## Store submission notes

- Description must state **unofficial**, not affiliated with Mojang/Microsoft.
- Privacy: **no data collection** (extension does not declare host permissions).
